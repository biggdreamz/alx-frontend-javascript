export default function returnHowManyArguments(...theArgs) {
  return theArgs.length;
}
