## 0x03. ES6 data manipulation
