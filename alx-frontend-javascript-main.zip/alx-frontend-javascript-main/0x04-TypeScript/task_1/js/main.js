"use strict";
exports.__esModule = true;
exports.printTeacher = void 0;
var printTeacher = function (firstName, lastName) {
  return firstName[0] + ". " + lastName;
};
exports.printTeacher = printTeacher;
