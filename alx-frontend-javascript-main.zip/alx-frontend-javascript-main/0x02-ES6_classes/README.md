## 0x02. ES6 classes
