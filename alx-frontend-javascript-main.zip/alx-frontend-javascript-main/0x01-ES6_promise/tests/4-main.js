import signUpUser from "./4-user-promise";

console.log(signUpUser("Bob", "Dylan"));
