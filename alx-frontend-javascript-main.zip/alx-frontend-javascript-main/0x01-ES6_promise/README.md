## 0x01. ES6 Promises
